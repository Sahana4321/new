package shop.buyAndSell.quickr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class quickrApplication {

	public static void main(String[] args) {
		SpringApplication.run(quickrApplication.class, args);
	}

}
