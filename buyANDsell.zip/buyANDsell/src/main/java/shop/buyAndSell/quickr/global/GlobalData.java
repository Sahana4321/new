package shop.buyAndSell.quickr.global;

import java.util.ArrayList;
import java.util.List;

public class GlobalData {

    public static List<String> images;
    
    static{
        images=new ArrayList<String>();
    }
    
}
