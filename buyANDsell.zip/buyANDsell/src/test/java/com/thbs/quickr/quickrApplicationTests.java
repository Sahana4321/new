package com.thbs.quickr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class quickrApplicationTests {

	@Test
	void contextLoads() {
	}

}
