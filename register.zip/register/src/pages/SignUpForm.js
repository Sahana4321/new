import React, { Component } from "react";
import { Link } from "react-router-dom";

class SignUpForm extends Component {
  constructor(){
    super()
     this.state = {
        regmsg : '',
        loginmsg : ''
    }
}
register = (event)=>{
    var ob = {
       
        name : this.name.value,
        email:this.email.value,
        address : this.address.value,
        password: this.password.value,
        phone:this.phone.value*1,
        city:this.city.value,
        state:this.state.value,
        country:this.country.value

    }

    fetch(`http://localhost:7777/auth/Register`,{
      method : 'POST',
      headers:{
          "Content-Type" : "application/json"
      },
      body : JSON.stringify(ob)
  }).then(response=>response.json()).then(data=>{
      console.log(data)
      this.setState({regmsg:data.data})
  });;

    console.log(ob)
    event.preventDefault()
} 



  render() {
    return (
      <div className="formCenter">
        <form onSubmit={this.register} className="formFields">
          <div className="formField">
            <label className="formFieldLabel" htmlFor="name">
              Full Name
            </label>
            <input
              type="text"
              ref={c=>this.name=c}
              id="name"
              className="formFieldInput"
              placeholder="Enter your full name"
              name="name"
             
            />
          </div>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="email">
              E-Mail Address
            </label>
            <input
              type="email"
              ref={c=>this.email=c}
              id="email"
              className="formFieldInput"
              placeholder="Enter your email"
              name="email"
             
            />
          </div>
        
          <div className="formField">
            <label className="formFieldLabel" htmlFor="number">
              Phone Number
            </label>
            <input
              type="number"
              ref={c=>this.phone=c}
              id="number"
              className="formFieldInput"
              placeholder="Enter your phone number"
              name="phone"
             
            />
          </div>
         
          <div className="formField">
            <label className="formFieldLabel" htmlFor="address">
               Address
            </label>
            <input
              type="address"
              ref={c=>this.address=c}
              id="address"
              className="formFieldInput"
              placeholder="Enter your Address"
              name="address"
             
            />
          </div>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="city">
               City
            </label>
            <input
              type="city"
              ref={c=>this.city=c}
              id="city"
              className="formFieldInput"
              placeholder="Enter your City"
              name="city"
             
            />
          </div>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="kstate">
               State
            </label>
            <input
              type="kstate"
              ref={c=>this.kstate=c}
              id="state"
              className="formFieldInput"
              placeholder="Enter your State"
              name="kstate"
             
            />
          </div>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="country">
               Country
            </label>
            <input
              type="country"
              ref={c=>this.country=c}
              id="country"
              className="formFieldInput"
              placeholder="Enter your Country"
              name="country"
             
            />
          </div>
          

          <div className="formField">
            <label className="formFieldLabel" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              ref={c=>this.password=c}
              id="password"
              className="formFieldInput"
              placeholder="Enter your password"
              name="password"
              
            />
          </div>

         
          <div className="formField">
            <button type="submit" name="register" class="register" value="Register" className="formFieldButton">Sign Up</button>
           
              
           
            
          </div>
           
        </form>
         <Link to="/sign-in" className="formFieldLink"></Link>
         <b style={{color:"red"}}>{this.state.regmsg}</b> 
      </div>
      
    );
  }
}
export default SignUpForm;
