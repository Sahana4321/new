import React, { Component } from "react";
import { Link } from "react-router-dom";
import {
  GoogleLoginButton,
  FacebookLoginButton
} from "react-social-login-buttons";

class SignInForm extends Component {
  constructor() {
    super();

    this.state = {
      email: "",
      password: ""
    }
  }

    login = (event)=>{
      var ob = {
         
          
          email:this.email.value,
          password: this.password.value,
         
      }
  
      fetch(`http://localhost:7777/auth/Login`,{
        method : 'POST',
        headers:{
            "Content-Type" : "application/json"
        },
        body : JSON.stringify(ob)
    }).then(response=>response.json()).then(data=>{
        console.log(data)
        this.setState({regmsg:data.data})
    });;
  
      console.log(ob)
      event.preventDefault()
  } 
  

  render() {
    return (
      <div className="formCenter">
        <form className="formFields" onSubmit={this.login}>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="email">
              E-Mail Address
            </label>
            <input
              type="email"
              ref={c=>this.email=c}
              id="email"
              className="formFieldInput"
              placeholder="Enter your email"
              name="email"
             
            />
          </div>

          <div className="formField">
            <label className="formFieldLabel" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              ref={c=>this.password=c}
              id="password"
              className="formFieldInput"
              placeholder="Enter your password"
              name="password"
             
            />
          </div>

          <div className="formField">
            <button type="submit" name="login" class="login" value="login"className="formFieldButton">Sign In</button>{" "}
            <Link to="/" className="formFieldLink">
              Create an account
            </Link>
          </div>

          <div className="socialMediaButtons">
            <div className="googleButton">
              <GoogleLoginButton onClick={() => alert()} />
            </div>

            <div className="instagramButton">
              <FacebookLoginButton onClick={"https://www.facebook.com/"} />
            </div>
          </div>
        </form>
      </div>
    );
    }
}

export default SignInForm;